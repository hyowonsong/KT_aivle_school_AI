from django.contrib import admin
from .models import chatHistory, User, Profile

admin.site.register(User)
admin.site.register(Profile)

@admin.register(chatHistory) #  chatHistory 모델 관리자 페이지에 등록
class chatHistoryAdmin(admin.ModelAdmin): # 모델 관리를 위해 admin.ModelAdmin 클래스를 상속
    list_display = ('datetime', 'question', 'answer')
    search_fields = ('question', 'answer') # 검색 필터 
    list_filter = ('datetime',) # 기간 필터 적용